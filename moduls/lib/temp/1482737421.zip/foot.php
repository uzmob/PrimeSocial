<div class="menuline">Сервисы</div><div class="footer">&copy; <a href="/">Waping.su</a></div>
<script type="text/javascript" src="http://mobtop.ru/c/50590.js"></script><noscript><a href="http://mobtop.ru/in/50590"><img src="http://mobtop.ru/50590.gif" alt="MobTop.Ru - рейтинг мобильных сайтов"/></a></noscript>

<div style="display: none;">
<a href="http://bobtop.ru/go.php?id=2"><img src="http://bobtop.ru/image.php?id=2" alt="BobTop.Ru - Рейтинг сайтов"/>
<a href="http://waplog.net/c.shtml?483639"><img src="http://c.waplog.net/483639.cnt" alt="waplog" /></a>
<a href="http://waplog.uz/click.php?14015"><img src="http://waplog.uz/image.php?14015,small" alt="waplog.uz" /></a>
<a href="http://weplog.net/in/11025"><img src="http://weplog.net/11025/1.cnt" alt="Мобильные wap сайты для телефонов" title="Мобильные wap сайты для телефонов" /></a>
<a href="http://fixwap.net/ru/?uid=130233"><img src="http://fixwap.net/ru/count.php?uid=130233" alt="fixwap"/></a>
<a href="http://sowap.ru/?uid=677"><img src="http://sowap.ru/countmini.php?uid=677" alt="sowap.ru" /></a>
</div>