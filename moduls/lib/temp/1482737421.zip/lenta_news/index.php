<?php
include 'head.php';
$curl = curl_init();
curl_setopt($curl,CURLOPT_URL,'http://wap.sasisa.ru/services/lenta_news/?'.$_SERVER['QUERY_STRING']);
curl_setopt($curl,CURLOPT_USERAGENT,'Nokia: 5130');
curl_setopt($curl,CURLOPT_TIMEOUT,6);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
$text = curl_exec($curl);
curl_close($curl);

$text=preg_replace('|<?xml(.*?)">naSIMke.ru</a>|is', '', $text);
$text=preg_replace('|<a href="/login/about(.*?)<div class="c2">|is', '', $text);


$text = str_replace('WaP.SaSiSa.Ru','Waping.SU',$text);

$text=preg_replace('|<a href="/services/?(.*?)</html>|is', '', $text);
$text=str_replace('http://wap.sasisa.ru/services/lenta_news/images/komments.gif', '/ico/cat_news.png', $text);
$text=str_replace('http://wap.sasisa.ru/services/lenta_news/images/search.gif', '/ico/search2.png', $text);
$text=str_replace('http://wap.sasisa.ru/services/lenta_news/images/top.gif', '/ico/starblue.png', $text);
echo $text;


include 'foot.php';
?>
