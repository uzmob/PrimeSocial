<?php

include '../head.php';
$curl = curl_init();
curl_setopt($curl,CURLOPT_URL,'http://wap.sasisa.ru/lib/book.php?'.$_SERVER['QUERY_STRING']);
curl_setopt($curl,CURLOPT_USERAGENT,'Nokia: 5130');
curl_setopt($curl,CURLOPT_TIMEOUT,6);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
$text = curl_exec($curl);
curl_close($curl);
$text=preg_replace('|<?xml(.*?)">naSIMke.ru</a>|is', '', $text);
$text=preg_replace('|<a href="/login/about(.*?)<div class="c2">|is', '', $text);
$text = str_replace('WaP.SaSiSa.Ru','WMCLUB.IN',$text);
$text=preg_replace('|<div class="c2"><a href="/services/?(.*?)</html>|is', '</a>', $text);
$text = str_replace('</div>','<br></div>',$text);
$text = str_replace('href="/lib/book.php','href="lib.php',$text);
$text=preg_replace('|<img src="http://wap.sasisa.ru/lib/images/komments.gi(.*?)<img|is', '<img', $text);
$text=preg_replace('|<div class="c1"><b><a href="index.php?(.*?)</div>|is', '', $text);
$text=preg_replace('|>На главную</a><br>(.*?)</html>|is', '>На главную</a><br>', $text);
$text=preg_replace('|<a href="autors.php(.*?)</a>|is', '<text>WMCLUB.IN</text>', $text);
$text=preg_replace('|<a href="list.php(.*?)>|is', '', $text);
$text = str_replace('<a href="get.php?','<a href="http://wap.sasisa.ru/lib/get.php?',$text);

echo $text;


include '../foot.php';
?>
