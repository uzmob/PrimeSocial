﻿<?php
echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=utf-8" />
<?php if(isset($refresh)) echo '<meta http-equiv="refresh" content="10;URL=?'.$rand.'" />'; ?>
<title>Waping.SU - ГДЗ для школьников</title>
<link rel="stylesheet" href="/style.css" type="text/css" />
<link rel="shortcut icon" href="/favicon.ico" />
</head>
<body>
<div class="green"><a href="/">Waping.Su - ГДЗ для школьников</a></div>