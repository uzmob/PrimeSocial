<?php

include 'head.php';
$curl = curl_init();
curl_setopt($curl,CURLOPT_URL,'http://wap.sasisa.ru/services/tv.php?'.$_SERVER['QUERY_STRING']);
curl_setopt($curl,CURLOPT_USERAGENT,'Nokia: 5130');
curl_setopt($curl,CURLOPT_TIMEOUT,6);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
$text = curl_exec($curl);
curl_close($curl);
$text=preg_replace('|<?xml(.*?)">naSIMke.ru</a>|is', '', $text);
$text=preg_replace('|<a href="/login/about(.*?)</div><div>|is', '</a>', $text);


$text = str_replace('WaP.SaSiSa.Ru','WMCLUB.IN',$text);
$text=preg_replace('|<div class="sec"><a href="/services/?(.*?)</html>|is', '</a>', $text);
$text = str_replace('</div>','<br></div>',$text);

echo $text;


include 'foot.php';
?>
